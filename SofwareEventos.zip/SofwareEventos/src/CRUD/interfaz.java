package CRUD;

import java.util.List;

public interface interfaz <T> {  

    // Métodos de la interfaz
    public List<T> listar(String texto);  // Método que devuelve una lista de tipo T
    public boolean insertar(T obj);  // Método para insertar un objeto de tipo T
    public boolean actualizar(T obj);  // Método para actualizar un objeto de tipo T
    public boolean desactivar(int id);  // Método para desactivar por ID
    public boolean activar(int id);  // Método para activar por ID
    public int total();  // Método que devuelve el total
    public boolean existe(String texto);  // Método para verificar existencia con un texto
}
