/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

/**
 *
 * @author juand
 */
public class servicios {

         private String  servicios;
         private String  streaming; 
         private String  rumba;
         private String  usuario;
         private String sobre_nosotros;
         private String grabaciones;
         private String contactos;
         private boolean activo;

    public servicios(String servicios, String striaming, String rumba, String usuario, String sobre_nosotros, String grabaciones, String contactos, boolean activo) {
        this.servicios = servicios;
        this.streaming = striaming;
        this.rumba = rumba;
        this.usuario = usuario;
        this.sobre_nosotros = sobre_nosotros;
        this.grabaciones = grabaciones;
        this.contactos = contactos;
        this.activo = activo;
    }

    public servicios() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getServicios() {
        return servicios;
    }

    public String getStriaming() {
        return streaming;
    }

    public String getRumba() {
        return rumba;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getSobre_nosotros() {
        return sobre_nosotros;
    }

    public String getGrabaciones() {
        return grabaciones;
    }

    public String getContactos() {
        return contactos;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setServicios(String servicios) {
        this.servicios = servicios;
    }

    public void setStriaming(String streaming) {
        this.streaming = streaming;
    }

    public void setRumba(String rumba) {
        this.rumba = rumba;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public void setSobre_nosotros(String sobre_nosotros) {
        this.sobre_nosotros = sobre_nosotros;
    }

    public void setGrabaciones(String grabaciones) {
        this.grabaciones = grabaciones;
    }

    public void setContactos(String contactos) {
        this.contactos = contactos;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    @Override
    public String toString() {
            return "eventos{" + "servicios=" + servicios + ", striaming=" + streaming + ", rumba=" + rumba + ", usuario=" + usuario + ", sobre_nosotros=" + sobre_nosotros + ", grabaciones=" + grabaciones + ", contactos=" + contactos + ", activo=" + activo + '}';
    }

    public String getservicios() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getstreaming() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getrumba() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getusuario() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getsobre_nosotros() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getcontactos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getgrabaciones() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setNombre(String nombre) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setDescripcion(String descripcion) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setId(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int getId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getNombre() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getDescripcion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
         
}
