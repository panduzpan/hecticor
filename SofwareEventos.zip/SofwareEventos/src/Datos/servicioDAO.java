package Datos;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import BaseDeDatos.conexion;
import CRUD.interfaz;
import entidades.servicios;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class servicioDAO implements interfaz<servicios> {
    private final conexion CON;
    private PreparedStatement ps;
    private ResultSet rs;
    private boolean resp;
    
    public servicioDAO(){
        CON=conexion.getInstancia();
    }
    
    
    @Override
    public List<servicios> listar(String texto) {
        List<servicios> registros=new ArrayList();
        try {
            ps=CON.conectar().prepareStatement("SELECT * FROM categoria WHERE nombre LIKE ?");
            ps.setString(1,"%" + texto +"%");
            rs=ps.executeQuery();
            while(rs.next()){
                registros.add(new servicios(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getBoolean(8)));
            }
            ps.close();
            rs.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally{
            ps=null;
            rs=null;
            CON.desconectar();
        }
        return registros;
    }

    @Override
    public boolean insertar(servicios obj) {
        resp=false;
        try {
            ps=CON.conectar().prepareStatement("INSERT INTO servicio (servicio,streaming,rumba,usuarios,sobre_nosotros,grabaciones,contactos, activo) VALUES (?,?,?,?,?,?,?,1)");
            ps.setString(1, obj.getservicios());
            ps.setString(2, obj.getstreaming());
            ps.setString(3, obj.getrumba());
            ps.setString(4, obj.getusuario());
            ps.setString(5, obj.getsobre_nosotros());
            ps.setString(6, obj.getgrabaciones());
            ps.setString(7, obj.getcontactos());
            if (ps.executeUpdate()>0){
                resp=true;
            }
            ps.close();
        }  catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally{
            ps=null;
            CON.desconectar();
        }
        return resp;
    }

    @Override
    public boolean actualizar(servicios obj) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean desactivar(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean activar(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int total() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean existe(String texto) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    } } 
